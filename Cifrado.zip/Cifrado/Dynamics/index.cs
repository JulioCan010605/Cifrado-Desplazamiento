Función cifrar():
    // Obtener el mensaje y la llave del HTML
    mensaje = ObtenerValor("mensaje")
    llave = ConvertirAEntero(ObtenerValor("llave"))

    // Llamar a la función para procesar el mensaje y mostrar el resultado
    resultado = procesarMensaje(mensaje, llave, Verdadero)
    mostrarResultado(resultado)

Función descifrar():
    // Obtener el mensaje y la llave del HTML
    mensaje = ObtenerValor("mensaje")
    llave = ConvertirAEntero(ObtenerValor("llave"))

    // Llamar a la función para procesar el mensaje y mostrar el resultado
    resultado = procesarMensaje(mensaje, llave, Falso)
    mostrarResultado(resultado)

Función procesarMensaje(mensaje, llave, cifrar):
    nuevoMensaje = Vacío

    Para cada caracter en mensaje:
        códigoCaracter = ObtenerCódigoCaracter(caracter)

        Si códigoCaracter está en el rango de letras mayúsculas:
            // Si el carácter es una letra mayúscula
            nuevoCódigoCaracter = CalcularNuevoCódigo(códigoCaracter, llave, cifrar, 65, 26)
            nuevoMensaje += ConvertirACaracter(nuevoCódigoCaracter)
        Sino, Si códigoCaracter está en el rango de letras minúsculas:
            // Si el carácter es una letra minúscula
            nuevoCódigoCaracter = CalcularNuevoCódigo(códigoCaracter, llave, cifrar, 97, 26)
            nuevoMensaje += ConvertirACaracter(nuevoCódigoCaracter)
        Sino:
            // Si el carácter no es una letra, se mantiene igual
            nuevoMensaje += caracter

    Devolver nuevoMensaje

Función CalcularNuevoCódigo(código, llave, cifrar, inicioRango, longitudRango):
    Si cifrar:
        Devolver (código - inicioRango + llave) % longitudRango + inicioRango
    Sino:
        Devolver (código - inicioRango - llave + longitudRango) % longitudRango + inicioRango

Función mostrarResultado(resultado):
    EstablecerTexto("resultado", resultado)

   