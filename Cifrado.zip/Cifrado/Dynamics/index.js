// Esta función se encarga de cifrar el mensaje

function cifrar() {

    // Obtiene el mensaje y la llave del HTML

    var mensaje = document.getElementById("mensaje").value;
    var llave = parseInt(document.getElementById("llave").value);

    // Llama a la función para procesar el mensaje y luego muestra el resultado

    var resultado = procesarMensaje(mensaje, llave, true);
    mostrarResultado(resultado);
}

// Esta función se encarga de descifrar el mensaje

function descifrar() {

    // Obtiene el mensaje y la llave del HTML

    var mensaje = document.getElementById("mensaje").value;
    var llave = parseInt(document.getElementById("llave").value);

    // Llama a la función para procesar el mensaje y luego muestra el resultado

    var resultado = procesarMensaje(mensaje, llave, false);
    mostrarResultado(resultado);
}

// Esta función procesa el mensaje, ya sea para cifrar o descifrar

function procesarMensaje(mensaje, llave, cifrar) {
    return mensaje.split('').map(function(caracter) {
        var charCode = caracter.charCodeAt(0);

        if (charCode >= 65 && charCode <= 90) {

            // Si el carácter es una letra mayúscula

            var nuevoCharCode = cifrar ? (charCode - 65 + llave) % 26 + 65 : (charCode - 65 - llave + 26) % 26 + 65;
            return String.fromCharCode(nuevoCharCode);
        } else if (charCode >= 97 && charCode <= 122) {

            // Si el carácter es una letra minúscula

            var nuevoCharCode = cifrar ? (charCode - 97 + llave) % 26 + 97 : (charCode - 97 - llave + 26) % 26 + 97;
            return String.fromCharCode(nuevoCharCode);
        } else {

            // Si el carácter no es una letra, se mantiene igual
            return caracter;
        }
    }).join('');
}

// Esta función muestra el resultado en el HTML

function mostrarResultado(resultado){
    document.getElementById("resultado").innerText = resultado;
}


